# Changelog

## 1.0.0 - 2026-09-01

- Initial release. Orange progress and a microphone icon on podcast tracks.
